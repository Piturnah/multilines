# multilines
Python module for formatting multi-line strings
